import{c as a,g as e}from"./chunk-IQMS3RTE.js";var l=a(e(),1),t=({className:n})=>(0,l.jsx)("div",{className:`animate-pulse transition-all bg-gray-200 ${n}`}),o=t;export{o as a};
